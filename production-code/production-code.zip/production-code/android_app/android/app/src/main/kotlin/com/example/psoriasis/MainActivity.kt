package com.example.kitsfee

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
